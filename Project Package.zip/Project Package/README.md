# Project Package data preparation

Open `code/01_prepare_model_data.ipynb` in desktop VS Code. Select a Python interpreter that already has `numpy`, `pandas`, `pyarrow`, and `pyreadr`, then run the cells in order. No R runtime is required and the notebook never installs packages. The same build can be run with `python code/prepare_model_data.py` from the project root.

The two original RDS files are the only data inputs. The 45 columns in `Q_Total_Data84.rds` are already quarter-ranked values in `[-0.5,0.5]`; the code does not re-rank them. Fixed cuts `-0.3,-0.1,0.1,0.3` create five bins. A value exactly on a cut belongs to the bin on its right, so the intervals are `[-0.5,-0.3)`, `[-0.3,-0.1)`, `[-0.1,0.1)`, `[0.1,0.3)`, and `[0.3,0.5]`.

Outputs:

| File | Meaning |
|---|---|
| `data/processed/firm_panel_python.parquet` | Original firm panel in Python format, with date and permno normalized |
| `data/processed/macro_vars_python.parquet` | Original macro series in Python format, with quarter end date |
| `data/model_data/Z_categories_45.npy` | `(rows,45)` int8 categories 0–4, with -1 for natural missing |
| `data/model_data/X_range_onehot_225.npy` | `(rows,225)` uint8; five mutually exclusive bits per characteristic |
| `data/model_data/R_observed_45.npy` | `(rows,45)` uint8 mask, 1 observed and 0 naturally missing |
| `data/model_data/row_index.parquet` | Stable row IDs, dates, securities, period markers, observed counts |
| `data/model_data/split_manifest.parquet` | 70/15/15 chronological split by unique quarter |
| `data/model_data/encoding_schema.json` | Ordered names, interval boundaries, semantics, shapes |
| `data/model_data/build_summary.json` | Counts, missingness, time ranges and split summary |

For an observed characteristic, exactly one of its five range bits is 1. For a naturally missing characteristic, all five bits are 0 and the separate observation mask is 0. Treat natural missingness as unknown; do not assign it to category 0 and do not score placeholder zeros. The 45-category array is the canonical model data and directly supports the factorized categorical benchmark. A generic Bernoulli model over 225 one-hot bits would put positive probability on impossible multi-hot and all-zero patterns, so MADE or probabilistic-circuit likelihoods require a group-aware or otherwise support-constrained design for an apples-to-apples likelihood comparison.
