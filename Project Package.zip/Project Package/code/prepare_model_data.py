"""Build Python research data from the two original RDS files.

Run from the project package with: python code/prepare_model_data.py
The only input files are data/raw/Q_Total_Data84.rds and Macro_vars.rds.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pyreadr


CUTS = np.array([-0.3, -0.1, 0.1, 0.3], dtype=np.float64)
RANGES = ["[-0.5, -0.3)", "[-0.3, -0.1)", "[-0.1, 0.1)", "[0.1, 0.3)", "[0.3, 0.5]"]
ID_COLUMNS = ["date", "permno", "Intervals", "Early_Years"]
MACRO_COLUMNS = ["dp", "ep", "bm", "ntis", "tbl", "tms", "dfy", "svar"]


def read_rds(path: Path) -> pd.DataFrame:
    result = pyreadr.read_r(str(path))
    if len(result) != 1:
        raise ValueError(f"Expected one object in {path}, found {len(result)}")
    return next(iter(result.values()))


def checked_integer(series: pd.Series, name: str) -> pd.Series:
    values = pd.to_numeric(series, errors="raise")
    if values.isna().any() or not np.all(values.to_numpy() == np.floor(values.to_numpy())):
        raise ValueError(f"{name} must contain nonmissing integers")
    return values.astype("int64")


def encode_panel(panel: pd.DataFrame, model_dir: Path) -> tuple[pd.DataFrame, list[str], dict]:
    if any(name not in panel.columns for name in ID_COLUMNS):
        raise ValueError("Firm panel lacks expected identifier columns")
    characteristics = [name for name in panel.columns if name not in ID_COLUMNS]
    if len(characteristics) != 45:
        raise ValueError(f"Expected 45 characteristics, found {len(characteristics)}")
    panel = panel.copy()
    panel["date"] = pd.to_datetime(checked_integer(panel["date"], "date").astype(str), format="%Y%m%d")
    panel["permno"] = checked_integer(panel["permno"], "permno")
    if panel.duplicated(["date", "permno"]).any():
        raise ValueError("Duplicate date + permno in firm panel")
    if not panel["date"].dt.is_quarter_end.all():
        raise ValueError("Firm dates must be quarter ends")

    n, d = len(panel), len(characteristics)
    values = panel[characteristics].to_numpy(dtype=np.float64, copy=True)
    finite = np.isfinite(values)
    if np.any(~np.isnan(values) & ~finite):
        raise ValueError("Infinite characteristic value encountered")
    if np.any(finite & ((values < -0.5 - 1e-12) | (values > 0.5 + 1e-12))):
        raise ValueError("Characteristic outside documented [-0.5, 0.5] rank range")

    observed = finite.astype(np.uint8)
    categories = np.full((n, d), -1, dtype=np.int8)
    onehot = np.zeros((n, d * 5), dtype=np.uint8)
    names: list[str] = []
    row_ids = np.arange(n, dtype=np.int64)
    for j, characteristic in enumerate(characteristics):
        is_observed = finite[:, j]
        row_index = row_ids[is_observed]
        category = np.searchsorted(CUTS, values[is_observed, j], side="right").astype(np.int8)
        categories[row_index, j] = category
        onehot[row_index, 5 * j + category.astype(np.intp)] = 1
        names.extend(f"{characteristic}__range_{k}" for k in range(5))

    # These checks catch accidental treatment of a natural NA as the lowest bin.
    if not np.array_equal(onehot.reshape(n, d, 5).sum(axis=2), observed):
        raise AssertionError("One-hot block sums must equal the observation mask")
    if not np.array_equal(categories >= 0, finite):
        raise AssertionError("Category missingness and observation mask disagree")
    if not np.array_equal(onehot.reshape(n, d, 5).argmax(axis=2)[finite], categories[finite]):
        raise AssertionError("One-hot and categorical encodings disagree")

    model_dir.mkdir(parents=True, exist_ok=True)
    np.save(model_dir / "Z_categories_45.npy", categories)
    np.save(model_dir / "X_range_onehot_225.npy", onehot)
    np.save(model_dir / "R_observed_45.npy", observed)

    rows = pd.DataFrame({
        "row_id": row_ids,
        "date": panel["date"],
        "permno": panel["permno"],
        "quarter": panel["date"].dt.to_period("Q").astype(str),
        "Intervals": panel["Intervals"].astype(str),
        "Early_Years": panel["Early_Years"].astype(bool),
        "observed_characteristics": observed.sum(axis=1).astype(np.uint8),
    })
    rows.to_parquet(model_dir / "row_index.parquet", index=False)
    schema = {
        "source": "data/raw/Q_Total_Data84.rds",
        "thresholds": CUTS.tolist(),
        "boundary_rule": "lower bound included; upper bound excluded except last bin includes 0.5",
        "ranges": RANGES,
        "characteristics": characteristics,
        "range_indicator_names": names,
        "category_shape": [n, d],
        "range_onehot_shape": [n, d * 5],
        "observation_mask_shape": [n, d],
        "observation_mask_semantics": "1=observed, 0=natural missing",
        "category_missing_sentinel": -1,
        "onehot_missing_semantics": "all five bits are zero only when the characteristic is naturally missing",
        "row_alignment": "Every array row matches row_index.parquet row_id and processed/firm_panel_python.parquet row order",
        "warning": "A generic 225-bit Bernoulli model gives mass to impossible one-hot patterns; use categorical or constrained likelihood for valid-support modeling.",
    }
    (model_dir / "encoding_schema.json").write_text(json.dumps(schema, indent=2), encoding="utf-8")

    summary = {
        "firm_rows": n,
        "characteristics": d,
        "unique_securities": int(panel["permno"].nunique()),
        "quarters": int(panel["date"].nunique()),
        "complete_case_rows": int(np.all(finite, axis=1).sum()),
        "naturally_missing_cells": int((~finite).sum()),
        "natural_missing_rate": float((~finite).mean()),
        "date_min": str(panel["date"].min().date()),
        "date_max": str(panel["date"].max().date()),
        "category_counts_observed": np.bincount(categories[finite], minlength=5).astype(int).tolist(),
        "missing_rate_by_characteristic": {
            name: float(1.0 - observed[:, j].mean()) for j, name in enumerate(characteristics)
        },
    }
    return panel, characteristics, summary


def process_macro(macro: pd.DataFrame, processed_dir: Path, firm_dates: pd.Series) -> dict:
    expected = ["Year", "Quarter", *MACRO_COLUMNS]
    if list(macro.columns) != expected:
        raise ValueError(f"Unexpected macro columns: {list(macro.columns)}")
    macro = macro.copy()
    macro["Year"] = checked_integer(macro["Year"], "macro Year")
    macro["Quarter"] = checked_integer(macro["Quarter"], "macro Quarter")
    if not macro["Quarter"].between(1, 4).all():
        raise ValueError("Macro Quarter outside 1..4")
    if macro.duplicated(["Year", "Quarter"]).any():
        raise ValueError("Duplicate macro Year + Quarter")
    if macro[MACRO_COLUMNS].isna().any().any():
        raise ValueError("Macro variables contain missing values")
    macro["date"] = pd.PeriodIndex.from_fields(year=macro["Year"], quarter=macro["Quarter"], freq="Q").to_timestamp(how="end").normalize()
    covered = set(firm_dates.unique()).issubset(set(macro["date"].unique()))
    if not covered:
        raise ValueError("Some firm quarters have no matching macro row")
    macro.to_parquet(processed_dir / "macro_vars_python.parquet", index=False)
    return {"macro_rows": len(macro), "macro_columns": MACRO_COLUMNS, "firm_quarters_all_covered": covered}


def make_chronological_split(model_dir: Path, rows: pd.DataFrame) -> dict:
    quarters = np.sort(rows["date"].unique())
    n = len(quarters)
    train_end = int(np.floor(0.70 * n))
    val_end = int(np.floor(0.85 * n))
    split = np.full(len(rows), "test", dtype=object)
    split[rows["date"].isin(quarters[:train_end]).to_numpy()] = "train"
    split[rows["date"].isin(quarters[train_end:val_end]).to_numpy()] = "validation"
    manifest = rows[["row_id", "date", "permno", "quarter"]].copy()
    manifest["split"] = split
    manifest.to_parquet(model_dir / "split_manifest.parquet", index=False)
    return {
        name: {
            "quarters": int(len(group["date"].unique())),
            "rows": int(len(group)),
            "first_quarter": str(group["quarter"].iloc[0]),
            "last_quarter": str(group["quarter"].iloc[-1]),
        }
        for name, group in manifest.groupby("split", sort=False)
    }


def build_dataset(project_root: Path) -> dict:
    project_root = Path(project_root).resolve()
    raw = project_root / "data" / "raw"
    processed = project_root / "data" / "processed"
    model = project_root / "data" / "model_data"
    panel_path, macro_path = raw / "Q_Total_Data84.rds", raw / "Macro_vars.rds"
    if not panel_path.is_file() or not macro_path.is_file():
        raise FileNotFoundError(f"Expected both RDS files in {raw}")
    processed.mkdir(parents=True, exist_ok=True)
    panel, characteristics, summary = encode_panel(read_rds(panel_path), model)
    panel.to_parquet(processed / "firm_panel_python.parquet", index=False)
    summary.update(process_macro(read_rds(macro_path), processed, panel["date"]))
    rows = pd.read_parquet(model / "row_index.parquet")
    summary["chronological_split"] = make_chronological_split(model, rows)
    summary["characteristic_order"] = characteristics
    (model / "build_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    result = build_dataset(args.project_root)
    print(json.dumps({k: v for k, v in result.items() if k not in ("characteristic_order", "missing_rate_by_characteristic")}, indent=2))
